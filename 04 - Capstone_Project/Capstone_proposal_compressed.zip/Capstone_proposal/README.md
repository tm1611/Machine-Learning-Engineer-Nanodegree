# README

## Datasets

There are various ways to acquire the respective data that are necessary for the project:

- Direct download from this site - https://www.mcompetitions.unic.ac.cy/the-dataset/
- On github - https://github.com/M4Competition/M4-methods/tree/master/Dataset
- Using R package - "M4comp2018"
- In Python - Using the API of Gluon Time Series (GluonTS) toolkit for probabilistic time series modeling: https://gluon-ts.mxnet.io/
